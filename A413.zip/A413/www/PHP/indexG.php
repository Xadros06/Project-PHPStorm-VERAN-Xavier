<?php 
echo $_GET["variable"];
  //echo json_encode($_GET["variable"]);

echo('{"prop1:"val1", "prop2":"val2"}');
?>


