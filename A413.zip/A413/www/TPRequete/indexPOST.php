<?php 
	//echo $_POST["mavar"]; //R�cup�re le parametre "mavar" (pour valeur ="string")
	echo '{"resultat" : "'.$_POST["mavar"].'"}';
?>