<?php 
	//echo $_GET["mavar"]; //Récupère le parametre "mavar" (pour valeur ="string") qui est dans l'URL voir .js (SendReq1)
	echo '{"resultat" : "'.$_GET["mavar"].'"}';
?>