var xhr = null;

function initXhr(){
  if(window.XMLHttpRequest){
    xhr = new XMLHttpRequest();
  }
  else if(window.ActiveXObject){
  xhr = new ActiveXObject("Microsoft.XMLHTTP");
  }
  else{
  console.log("Votre navigateur ne supporte pas XMLHTPRESUEST");
  }
}

initXhr();

xhr.onreadystatechange = function(){ //quand je récupère ma réponse
  if(xhr.readyState == 4 && xhr.status == 200){ //si réponse '4' et '200' alors valide
    maCallback(xhr.responseText);  //alors j'appelle MycallBack qui va modifier l'HTML
  }
};

function maCallback(response){ //Va servir à récupérer la reponse du PHP, pour sendReq1=IndexGET, pour modfier l'HTML, ici rajoue le echo de IndexGET 

  var h1 = document.createElement('h1');
	console.log(eval('(' + response + ')')["resultat"]);
  //h1.appendChild(document.createTextNode(response)) //On donne à H1 la réponse du php pour que H1 est une valeur
  h1.appendChild(document.createTextNode(eval('(' + response + ')')["resultat"])); //affichage pour Json
  document.body.appendChild(h1); //ajoute H1 au body
}

function pageLoaded(){
  document.getElementById("req_get").addEventListener("click", sendReq1);
  document.getElementById("req_post").addEventListener("click", sendReq2);
  //sendReq1();

}

function sendReq1(){
  xhr.open('get', "http://localhost/TPRequete/indexGET.php?mavar=valeur", true);
  xhr.send(null);
}
function sendReq2(){
  xhr.open('post', "http://localhost/TPRequete/indexPOST.php", true);
  xhr.setRequestHeader('Content-Type', "application/x-www-form-urlencoded");
  xhr.send("mavar="+document.getElementById("btn_post").value); //Comme rajoute e post alors envvoit parametre
}

function selectionRss(address){
  chr.open('get',address, true);
  xhr.send(null);
}
