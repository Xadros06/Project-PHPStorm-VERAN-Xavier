<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>TP n°4 - VERAN Xavier</title>
  <script src="TD2.js"></script>
</head>

<body onload="pageLoaded()">

<button type="button" id="req_get">Requête GET</button>
<br><br>
<input type="text" id="btn_post" />
<button type="button" id="req_post">Requête POST</button>

</body>

</html>

<!-- 
header('Contente-Type: application/json');
echo (json_encode('{"prop1":"vall","prop2":"val2"});
!-->