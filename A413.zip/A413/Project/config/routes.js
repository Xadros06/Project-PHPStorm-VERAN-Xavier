module.exports.routes = {
  '/': {
    view: 'homepage'
  },
   'get /login': {
          view: 'login'
     },

     'post /login': 'AuthController.login',

     '/logout': 'AuthController.logout',

     'get /signup': {
       view: 'signup'
     },

    'get /monCompte': {
     controller : 'UserController',
     action : 'moncompte'
    },

    'get /monCompte/test': {
         controller : 'UserController',
         action : 'test'
        },

    'get /Participants': {
         view : 'Participant'
        },

    'post /monCompte/UploadAvatar' : {
     controller : 'UserController',
     action : 'AvatarUpload'
    }

};
