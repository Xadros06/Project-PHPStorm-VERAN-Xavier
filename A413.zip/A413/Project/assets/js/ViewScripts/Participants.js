  var toto = "Salut";

  function test(arg1) {
          alert(arg1);

          var jesuisdanstest = "ben oui";
  }


var calcul = function() {
    alert('calcul');
    };

    test('ça marche');

