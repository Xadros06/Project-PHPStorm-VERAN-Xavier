$(document).ready(function() {

  var addressId = -1;

  $('#req_get').click(function () {
    $.post("/monCompte/test", function (data) {

      addressId = data.adresses[0].id;
      $('#result2').html(data.email);
      $.each(data.adresses, function(index, value){
        console.log('value');
        $('#result2').html($('#result2').html() + value.codepostal)

      });
    });
  });

  $('#set_address').click(function () {
    $.post("/address/" + addressId, {codepostal:"06000"}, function (data) {
        alert(data);
    });
  });
});
