
module.exports = {

 attributes: {
         adresse: {
                      type: 'string'
          },

         codepostal: {
                       type: 'integer'
         },

         owner: {
                  model: 'user'
         }
     }

};



